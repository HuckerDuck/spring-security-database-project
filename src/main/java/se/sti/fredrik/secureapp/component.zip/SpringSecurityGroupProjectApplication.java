package se.sti.fredrik.secureapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityGroupProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityGroupProjectApplication.class, args);
    }

}
