package se.sti.fredrik.secureapp.Config;

public class RoutePaths {
    public static final String ADMIN_BASE = "/admin";
    public static final String USER_BASE = "/user";
    public static final String AUTH_BASE = "/auth";
}
